// src/server/studio-server.ts
import express from "express";
import path3 from "node:path";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";

// src/lib/logger.ts
var LEVEL_LABELS = {
  [0 /* TRACE */]: "TRACE",
  [1 /* DEBUG */]: "DEBUG",
  [2 /* INFO */]: "INFO",
  [3 /* WARN */]: "WARN",
  [4 /* ERROR */]: "ERROR",
  [5 /* NONE */]: ""
};
function parseLogLevel(value) {
  switch (value?.toLowerCase()) {
    case "trace":
      return 0 /* TRACE */;
    case "debug":
      return 1 /* DEBUG */;
    case "info":
      return 2 /* INFO */;
    case "warn":
      return 3 /* WARN */;
    case "error":
      return 4 /* ERROR */;
    case "none":
      return 5 /* NONE */;
    default:
      return 2 /* INFO */;
  }
}
var configuredLevel = parseLogLevel(process.env["LOG_LEVEL"]);
function safeStringify(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return '{"_serializeError":"circular or non-serializable data"}';
  }
}
function createLoggerImpl(bindings) {
  function emit(level, event, data) {
    if (level < configuredLevel) return;
    const merged = { ...bindings, ...data };
    const label = LEVEL_LABELS[level];
    const hasExtra = Object.keys(merged).length > 0;
    const output = hasExtra ? `[${label}] [studio] ${event} ${safeStringify(merged)}
` : `[${label}] [studio] ${event}
`;
    process.stderr.write(output);
  }
  return {
    trace: (event, data) => emit(0 /* TRACE */, event, data),
    debug: (event, data) => emit(1 /* DEBUG */, event, data),
    info: (event, data) => emit(2 /* INFO */, event, data),
    warn: (event, data) => emit(3 /* WARN */, event, data),
    error: (event, data) => emit(4 /* ERROR */, event, data),
    child(childBindings) {
      return createLoggerImpl({ ...bindings, ...childBindings });
    }
  };
}
var logger = createLoggerImpl({});

// src/server/middleware/cors.ts
var DEFAULT_ALLOWED_ORIGIN = "http://localhost:3847";
var CORS_ORIGINS_ENV_KEY = "STUDIO_CORS_ORIGINS";
var ALLOWED_METHODS = "GET, POST, PUT, DELETE, OPTIONS";
var ALLOWED_HEADERS = "Content-Type, Authorization";
function getAllowedOrigins() {
  const envValue = process.env[CORS_ORIGINS_ENV_KEY];
  if (!envValue) return [DEFAULT_ALLOWED_ORIGIN];
  return envValue.split(",").map((origin) => origin.trim()).filter(Boolean);
}
function corsMiddleware(req, res, next) {
  const origin = req.headers.origin;
  if (!origin) {
    next();
    return;
  }
  const host = req.headers.host;
  if (host && origin === `http://${host}`) {
    next();
    return;
  }
  if (host && origin === `https://${host}`) {
    next();
    return;
  }
  const allowedOrigins = getAllowedOrigins();
  if (!allowedOrigins.includes(origin)) {
    res.status(403).json({ error: "Origin not allowed" });
    return;
  }
  res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Access-Control-Allow-Methods", ALLOWED_METHODS);
  res.setHeader("Access-Control-Allow-Headers", ALLOWED_HEADERS);
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Max-Age", "86400");
    res.status(204).end();
    return;
  }
  next();
}

// src/lib/errors.ts
var StudioError = class extends Error {
  code;
  statusCode;
  context;
  constructor(code, message, statusCode, context = {}, cause) {
    super(message, { cause });
    this.name = "StudioError";
    this.code = code;
    this.statusCode = statusCode;
    this.context = context;
  }
  toJSON() {
    return {
      name: this.name,
      code: this.code,
      message: this.message,
      context: this.context,
      ...this.cause instanceof Error ? { cause: { name: this.cause.name, message: this.cause.message } } : this.cause !== void 0 ? { cause: String(this.cause) } : {}
    };
  }
};
var StudioStorageError = class extends StudioError {
  operation;
  constructor(message, options) {
    super("STUDIO_STORAGE_ERROR", message, 500, {
      operation: options.operation,
      ...options.context
    }, options.cause);
    this.name = "StudioStorageError";
    this.operation = options.operation;
  }
};
var StudioPublishError = class extends StudioError {
  constructor(message, options = {}) {
    super("STUDIO_PUBLISH_ERROR", message, 500, options.context ?? {}, options.cause);
    this.name = "StudioPublishError";
  }
};
var StudioPathError = class extends StudioError {
  filePath;
  constructor(message, options) {
    super("STUDIO_PATH_ERROR", message, 400, { filePath: options.filePath });
    this.name = "StudioPathError";
    this.filePath = options.filePath;
  }
};
var StudioFeatureUnavailableError = class extends StudioError {
  feature;
  constructor(feature, message) {
    super(
      "STUDIO_FEATURE_UNAVAILABLE",
      message ?? `Feature '${feature}' is not available in this environment`,
      501,
      { feature }
    );
    this.name = "StudioFeatureUnavailableError";
    this.feature = feature;
  }
};

// src/server/middleware/error-handler.ts
function errorHandler(err, _req, res, _next) {
  if (err instanceof StudioError) {
    logger.error("route_error", {
      code: err.code,
      message: err.message,
      statusCode: err.statusCode,
      ...err.context
    });
    res.status(err.statusCode).json({
      error: { code: err.code, message: err.message, ...err.context }
    });
    return;
  }
  const message = err instanceof Error ? err.message : String(err);
  logger.error("route_unexpected_error", { message });
  res.status(500).json({
    error: { code: "INTERNAL_ERROR", message: "An unexpected error occurred" }
  });
}

// src/lib/event-bridge.ts
import { NOTIFY_CHANNELS as NOTIFY_CHANNELS2 } from "@amodalai/db";

// src/lib/pg-listener.ts
import { createPgListener, NOTIFY_CHANNELS } from "@amodalai/db";
var listener = null;
var DATABASE_URL_ENV = "DATABASE_URL";
async function getPgListener() {
  if (listener) return listener;
  const url = process.env[DATABASE_URL_ENV];
  if (!url) {
    throw new Error(`${DATABASE_URL_ENV} is required for Postgres LISTEN`);
  }
  const start = Date.now();
  listener = await createPgListener(url);
  for (const channel of NOTIFY_CHANNELS) {
    await listener.listen(channel);
  }
  logger.info("pg_listener_initialized", {
    channels: NOTIFY_CHANNELS.length,
    duration_ms: Date.now() - start
  });
  return listener;
}
async function closePgListener() {
  if (listener) {
    await listener.close();
    listener = null;
  }
}

// src/lib/event-bus.ts
import { EventEmitter } from "node:events";
var StudioEventBus = class {
  emitter = new EventEmitter();
  seq = 0;
  emit(type, payload) {
    this.seq++;
    const event = {
      type,
      payload,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      seq: this.seq
    };
    this.emitter.emit("event", event);
  }
  subscribe(handler) {
    this.emitter.on("event", handler);
    return () => {
      this.emitter.off("event", handler);
    };
  }
};
var bus = null;
function getEventBus() {
  if (!bus) bus = new StudioEventBus();
  return bus;
}

// src/lib/event-bridge.ts
var bridged = false;
async function initEventBridge() {
  if (bridged) return;
  bridged = true;
  const listener2 = await getPgListener();
  const bus2 = getEventBus();
  for (const channel of NOTIFY_CHANNELS2) {
    listener2.on(channel, (payload) => {
      logger.debug("pg_notification", { channel, payload });
      bus2.emit(channel, payload);
    });
  }
  logger.info("event_bridge_initialized", { channels: NOTIFY_CHANNELS2.length });
}

// src/lib/eval-loader.ts
import * as fs from "node:fs/promises";
import * as path from "node:path";

// src/lib/eval-queries.ts
import { eq, desc, evalSuites, evalRuns } from "@amodalai/db";

// src/lib/db.ts
import { getDb, ensureSchema } from "@amodalai/db";
var initialized = false;
async function getStudioDb() {
  const db = getDb();
  if (!initialized) {
    const start = Date.now();
    await ensureSchema(db);
    initialized = true;
    logger.info("studio_db_initialized", { duration_ms: Date.now() - start });
  }
  return db;
}

// src/lib/eval-queries.ts
var DEFAULT_RUNS_LIMIT = 100;
async function listEvalSuites(agentId) {
  const db = await getStudioDb();
  return db.select().from(evalSuites).where(eq(evalSuites.agentId, agentId)).orderBy(desc(evalSuites.createdAt));
}
async function getEvalSuite(id) {
  const db = await getStudioDb();
  const rows = await db.select().from(evalSuites).where(eq(evalSuites.id, id)).limit(1);
  return rows[0] ?? null;
}
async function listEvalRuns(suiteId, limit = DEFAULT_RUNS_LIMIT) {
  const db = await getStudioDb();
  return db.select().from(evalRuns).where(eq(evalRuns.suiteId, suiteId)).orderBy(desc(evalRuns.createdAt)).limit(limit);
}
async function upsertEvalSuite(agentId, name, config) {
  const db = await getStudioDb();
  const id = `${agentId}:${name}`;
  const now = /* @__PURE__ */ new Date();
  await db.insert(evalSuites).values({
    id,
    agentId,
    name,
    config,
    createdAt: now
  }).onConflictDoUpdate({
    target: evalSuites.id,
    set: { name, config }
  });
}
async function saveEvalRun(run) {
  const db = await getStudioDb();
  await db.insert(evalRuns).values({
    id: run.id,
    agentId: run.agentId,
    suiteId: run.suiteId,
    model: run.model,
    results: run.results,
    passRate: run.passRate,
    totalPassed: run.totalPassed,
    totalFailed: run.totalFailed,
    durationMs: run.durationMs,
    triggeredBy: run.triggeredBy,
    label: run.label ?? null,
    gitSha: run.gitSha ?? null,
    costMicros: run.costMicros ?? null
  });
}

// src/lib/eval-loader.ts
function extractSections(content) {
  const sections = {};
  const sectionRe = /^##\s+(.+)$/gm;
  let match;
  const boundaries = [];
  while ((match = sectionRe.exec(content)) !== null) {
    boundaries.push({
      name: match[1].trim(),
      start: match.index + match[0].length
    });
  }
  for (let i = 0; i < boundaries.length; i++) {
    const boundary = boundaries[i];
    const end = i + 1 < boundaries.length ? boundaries[i + 1].start - boundaries[i + 1].name.length - 3 : content.length;
    sections[boundary.name] = content.slice(boundary.start, end).trim();
  }
  return sections;
}
function parseAssertions(text) {
  const assertions = [];
  for (const line of text.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("- ")) continue;
    const assertionText = trimmed.slice(2).trim();
    if (!assertionText) continue;
    const negated = /^Should\s+(?:NOT|not)\s+/i.test(assertionText);
    assertions.push({ text: assertionText, negated });
  }
  return assertions;
}
function parseEvalFile(content, fileName) {
  const name = fileName.replace(/\.md$/, "");
  const titleMatch = /^#\s+(?:Eval:\s+)?(.+)$/m.exec(content);
  const title = titleMatch ? titleMatch[1].trim() : name;
  let description = "";
  if (titleMatch) {
    const afterTitle = content.slice(titleMatch.index + titleMatch[0].length);
    const firstSection = afterTitle.search(/^##\s+/m);
    if (firstSection >= 0) {
      description = afterTitle.slice(0, firstSection).trim();
    } else {
      description = afterTitle.trim();
    }
  }
  const sections = extractSections(content);
  let query = (sections["Query"] ?? "").trim();
  const quoteMatch = /^"(.+)"$/s.exec(query);
  if (quoteMatch) {
    query = quoteMatch[1];
  }
  const assertions = parseAssertions(sections["Assertions"] ?? "");
  return { name, title, description, query, assertions };
}
async function loadEvalsFromDisk(repoPath, agentId) {
  const evalsDir = path.join(repoPath, "evals");
  let entries;
  try {
    const dirEntries = await fs.readdir(evalsDir, { withFileTypes: true });
    entries = dirEntries.filter((e) => e.isFile() && e.name.endsWith(".md")).map((e) => e.name);
  } catch (err) {
    if (err != null && typeof err === "object" && "code" in err && err.code === "ENOENT") {
      logger.debug("eval_loader_no_dir", { evalsDir });
      return 0;
    }
    throw err;
  }
  if (entries.length === 0) {
    logger.debug("eval_loader_empty", { evalsDir });
    return 0;
  }
  let loaded = 0;
  for (const fileName of entries) {
    const filePath = path.join(evalsDir, fileName);
    try {
      const content = await fs.readFile(filePath, "utf-8");
      const parsed = parseEvalFile(content, fileName);
      await upsertEvalSuite(agentId, parsed.name, {
        title: parsed.title,
        description: parsed.description,
        query: parsed.query,
        assertions: parsed.assertions,
        cases: parsed.query ? [{ input: parsed.query, expected: void 0 }] : []
      });
      loaded++;
    } catch (err) {
      logger.warn("eval_loader_file_error", {
        filePath,
        error: err instanceof Error ? err.message : String(err)
      });
    }
  }
  logger.info("eval_loader_complete", { evalsDir, loaded, total: entries.length });
  return loaded;
}

// src/lib/drizzle-backend.ts
import * as fs2 from "node:fs/promises";
import * as path2 from "node:path";
import { createHash } from "node:crypto";
import { eq as eq2, and, getDb as getDb2, ensureSchema as ensureSchema2, studioDrafts } from "@amodalai/db";
var WORKSPACE_DIRECTORIES = [
  "skills",
  "knowledge",
  "connections",
  "automations",
  "stores",
  "agents",
  "tools",
  "pages",
  "public"
];
var WORKSPACE_ROOT_FILES = [
  "amodal.json"
];
function isEnoentError(err) {
  return err != null && typeof err === "object" && "code" in err && err.code === "ENOENT";
}
async function walkDirectory(dirPath, basePath) {
  const files = [];
  let entries;
  try {
    entries = await fs2.readdir(dirPath);
  } catch (err) {
    if (isEnoentError(err)) {
      return files;
    }
    throw err;
  }
  for (const entryName of entries) {
    const fullPath = path2.join(dirPath, entryName);
    const relativePath = path2.relative(basePath, fullPath);
    const stat2 = await fs2.stat(fullPath);
    if (stat2.isDirectory()) {
      const subFiles = await walkDirectory(fullPath, basePath);
      files.push(...subFiles);
    } else if (stat2.isFile()) {
      try {
        const content = await fs2.readFile(fullPath, "utf-8");
        files.push({ path: relativePath, content });
      } catch (readErr) {
        logger.warn("workspace_file_skip", {
          filePath: relativePath,
          reason: readErr instanceof Error ? readErr.message : String(readErr)
        });
      }
    }
  }
  return files;
}
var DrizzleStudioBackend = class {
  db;
  repoPath;
  log = logger.child({ backend: "drizzle" });
  constructor(options) {
    this.repoPath = options.repoPath;
    this.db = getDb2();
  }
  async initialize() {
    const start = Date.now();
    try {
      await ensureSchema2(this.db);
      this.log.info("backend_initialized", { durationMs: Date.now() - start });
    } catch (err) {
      throw new StudioStorageError("Failed to initialize database", {
        operation: "initialize",
        cause: err
      });
    }
  }
  // -------------------------------------------------------------------------
  // Draft CRUD
  // -------------------------------------------------------------------------
  async listDrafts(userId) {
    const start = Date.now();
    try {
      const rows = await this.db.select({
        filePath: studioDrafts.filePath,
        content: studioDrafts.content,
        updatedAt: studioDrafts.updatedAt
      }).from(studioDrafts).where(eq2(studioDrafts.userId, userId)).orderBy(studioDrafts.filePath);
      this.log.debug("list_drafts", { userId, count: rows.length, durationMs: Date.now() - start });
      return rows.map((row) => ({
        filePath: row.filePath,
        content: row.content,
        updatedAt: row.updatedAt.toISOString()
      }));
    } catch (err) {
      throw new StudioStorageError("Failed to list drafts", {
        operation: "listDrafts",
        cause: err,
        context: { userId }
      });
    }
  }
  async readDraft(userId, filePath) {
    const start = Date.now();
    try {
      const rows = await this.db.select({
        filePath: studioDrafts.filePath,
        content: studioDrafts.content,
        updatedAt: studioDrafts.updatedAt
      }).from(studioDrafts).where(and(eq2(studioDrafts.userId, userId), eq2(studioDrafts.filePath, filePath))).limit(1);
      this.log.debug("read_draft", { userId, filePath, found: rows.length > 0, durationMs: Date.now() - start });
      if (rows.length === 0) return null;
      const row = rows[0];
      return {
        filePath: row.filePath,
        content: row.content,
        updatedAt: row.updatedAt.toISOString()
      };
    } catch (err) {
      throw new StudioStorageError("Failed to read draft", {
        operation: "readDraft",
        cause: err,
        context: { userId, filePath }
      });
    }
  }
  async saveDraft(userId, filePath, content) {
    const start = Date.now();
    try {
      await this.db.insert(studioDrafts).values({ userId, filePath, content, updatedAt: /* @__PURE__ */ new Date() }).onConflictDoUpdate({
        target: [studioDrafts.userId, studioDrafts.filePath],
        set: { content, updatedAt: /* @__PURE__ */ new Date() }
      });
      this.log.debug("save_draft", { userId, filePath, durationMs: Date.now() - start });
    } catch (err) {
      throw new StudioStorageError("Failed to save draft", {
        operation: "saveDraft",
        cause: err,
        context: { userId, filePath }
      });
    }
  }
  async deleteDraft(userId, filePath) {
    const start = Date.now();
    try {
      await this.db.delete(studioDrafts).where(and(eq2(studioDrafts.userId, userId), eq2(studioDrafts.filePath, filePath)));
      this.log.debug("delete_draft", { userId, filePath, durationMs: Date.now() - start });
    } catch (err) {
      throw new StudioStorageError("Failed to delete draft", {
        operation: "deleteDraft",
        cause: err,
        context: { userId, filePath }
      });
    }
  }
  async discardAllDrafts(userId) {
    const start = Date.now();
    try {
      const deleted = await this.db.delete(studioDrafts).where(eq2(studioDrafts.userId, userId)).returning({ filePath: studioDrafts.filePath });
      const count3 = deleted.length;
      this.log.info("discard_all_drafts", { userId, count: count3, durationMs: Date.now() - start });
      return count3;
    } catch (err) {
      throw new StudioStorageError("Failed to discard all drafts", {
        operation: "discardAllDrafts",
        cause: err,
        context: { userId }
      });
    }
  }
  // -------------------------------------------------------------------------
  // Publish
  // -------------------------------------------------------------------------
  async publishDrafts(userId) {
    const start = Date.now();
    const drafts = await this.listDrafts(userId);
    if (drafts.length === 0) {
      return { commitRef: "local-noop", filesPublished: 0 };
    }
    for (const draft of drafts) {
      const targetPath = path2.join(this.repoPath, draft.filePath);
      try {
        await fs2.mkdir(path2.dirname(targetPath), { recursive: true });
        await fs2.writeFile(targetPath, draft.content, "utf-8");
      } catch (err) {
        throw new StudioPublishError(
          `Failed to write draft file '${draft.filePath}' to disk`,
          {
            cause: err,
            context: { filePath: draft.filePath, targetPath }
          }
        );
      }
    }
    await this.discardAllDrafts(userId);
    const contentHash = createHash("sha256").update(drafts.map((d) => `${d.filePath}:${d.content}`).join("\n")).digest("hex").slice(0, 12);
    const commitRef = `local-${contentHash}`;
    this.log.info("publish_drafts", {
      userId,
      filesPublished: drafts.length,
      commitRef,
      durationMs: Date.now() - start
    });
    return { commitRef, filesPublished: drafts.length };
  }
  // -------------------------------------------------------------------------
  // Workspace
  // -------------------------------------------------------------------------
  async getWorkspace() {
    const start = Date.now();
    const files = [];
    for (const dir of WORKSPACE_DIRECTORIES) {
      const dirPath = path2.join(this.repoPath, dir);
      const dirFiles = await walkDirectory(dirPath, this.repoPath);
      files.push(...dirFiles);
    }
    for (const rootFile of WORKSPACE_ROOT_FILES) {
      const filePath = path2.join(this.repoPath, rootFile);
      try {
        const content = await fs2.readFile(filePath, "utf-8");
        files.push({ path: rootFile, content });
      } catch (err) {
        if (!isEnoentError(err)) {
          logger.warn("workspace_root_file_error", {
            filePath: rootFile,
            reason: err instanceof Error ? err.message : String(err)
          });
        }
      }
    }
    let agentId = path2.basename(this.repoPath);
    const amodalJsonFile = files.find((f) => f.path === "amodal.json");
    if (amodalJsonFile) {
      try {
        const parsed = JSON.parse(amodalJsonFile.content);
        if (typeof parsed === "object" && parsed !== null && "name" in parsed) {
          const name = parsed["name"];
          if (typeof name === "string" && name.length > 0) {
            agentId = name;
          }
        }
      } catch {
        logger.warn("workspace_amodal_json_parse_error", { repoPath: this.repoPath });
      }
    }
    this.log.info("get_workspace", { agentId, fileCount: files.length, durationMs: Date.now() - start });
    return { agentId, files };
  }
};

// src/lib/startup.ts
var REPO_PATH_ENV_KEY = "REPO_PATH";
var backendFactory = null;
var backendPromise = null;
function getBackend(req) {
  if (backendFactory) {
    if (!req) {
      throw new Error(
        "BackendFactory is set but no request was provided to getBackend(). Pass the Request so the factory can resolve the correct backend."
      );
    }
    return backendFactory(req);
  }
  if (backendPromise) return backendPromise;
  backendPromise = initializeBackend();
  return backendPromise;
}
async function initializeBackend() {
  const repoPath = process.env[REPO_PATH_ENV_KEY];
  if (!repoPath) {
    throw new Error(
      `${REPO_PATH_ENV_KEY} environment variable is required. Set it to the path of the agent repo being edited.`
    );
  }
  logger.info("backend_startup", { repoPath });
  const backend = new DrizzleStudioBackend({ repoPath });
  await backend.initialize();
  return backend;
}

// src/lib/config.ts
var AGENT_ID_ENV_KEY = "AGENT_ID";
var AGENT_NAME_ENV_KEY = "AGENT_NAME";
var RUNTIME_URL_ENV_KEY = "RUNTIME_URL";
var ADMIN_AGENT_URL_ENV_KEY = "ADMIN_AGENT_URL";
var DEFAULT_AGENT_ID = "default";
var DEFAULT_AGENT_NAME = "default";
var DEFAULT_RUNTIME_URL = "http://localhost:3847";
function getAgentId() {
  return process.env[AGENT_ID_ENV_KEY] ?? DEFAULT_AGENT_ID;
}
function getAgentName() {
  return process.env[AGENT_NAME_ENV_KEY] ?? process.env[AGENT_ID_ENV_KEY] ?? DEFAULT_AGENT_NAME;
}
function getRuntimeUrl() {
  return process.env[RUNTIME_URL_ENV_KEY] ?? DEFAULT_RUNTIME_URL;
}
function getAdminAgentUrl() {
  return process.env[ADMIN_AGENT_URL_ENV_KEY] ?? null;
}

// src/server/routes/config.ts
import { Router } from "express";

// src/server/route-helpers.ts
function asyncHandler(fn) {
  return (req, res, next) => {
    fn(req, res, next).catch(next);
  };
}

// src/server/routes/config.ts
var configRouter = Router();
configRouter.get("/api/studio/config", asyncHandler(async (_req, res) => {
  res.json({
    agentName: getAgentName(),
    runtimeUrl: getRuntimeUrl(),
    agentId: getAgentId()
  });
}));

// src/server/routes/workspace.ts
import { Router as Router2 } from "express";
var workspaceRouter = Router2();
workspaceRouter.get("/api/studio/workspace", asyncHandler(async (_req, res) => {
  const backend = await getBackend();
  const workspace = await backend.getWorkspace();
  res.json(workspace);
}));

// src/server/routes/drafts.ts
import { Router as Router3 } from "express";

// src/lib/auth.ts
var authProvider = null;
var LOCAL_DEV_USER = {
  userId: "local-dev",
  displayName: "Local Developer"
};
var LocalDevAuth = class {
  async getUser(_req) {
    return LOCAL_DEV_USER;
  }
};
var localDevAuth = new LocalDevAuth();
async function getUser(req) {
  const provider = authProvider ?? localDevAuth;
  return provider.getUser(req);
}

// src/lib/draft-path.ts
var ALLOWED_DIRECTORIES = [
  "skills/",
  "knowledge/",
  "connections/",
  "automations/",
  "stores/",
  "agents/",
  "tools/",
  "pages/",
  "public/"
];
var ALLOWED_ROOT_FILES = [
  "amodal.json"
];
function validateDraftPath(rawPath) {
  const filePath = rawPath.trim();
  if (filePath.length === 0) {
    throw new StudioPathError("File path must not be empty", { filePath: rawPath });
  }
  if (filePath.includes("\0")) {
    throw new StudioPathError("File path must not contain null bytes", { filePath });
  }
  if (filePath.startsWith("/")) {
    throw new StudioPathError("File path must be relative, not absolute", { filePath });
  }
  if (filePath.includes("..")) {
    throw new StudioPathError("File path must not contain path traversal segments", { filePath });
  }
  const isAllowedDirectory = ALLOWED_DIRECTORIES.some((dir) => filePath.startsWith(dir));
  const isAllowedRootFile = ALLOWED_ROOT_FILES.some((f) => filePath === f);
  if (!isAllowedDirectory && !isAllowedRootFile) {
    throw new StudioPathError(
      `File path must be under one of: ${ALLOWED_DIRECTORIES.join(", ")} or be one of: ${ALLOWED_ROOT_FILES.join(", ")}`,
      { filePath }
    );
  }
  return filePath;
}

// src/server/routes/drafts.ts
var draftsRouter = Router3();
draftsRouter.get("/api/studio/drafts", asyncHandler(async (req, res) => {
  const user = await getUser(req);
  const backend = await getBackend();
  const drafts = await backend.listDrafts(user.userId);
  res.json({ drafts });
}));
draftsRouter.post("/api/studio/drafts/batch", asyncHandler(async (req, res) => {
  const user = await getUser(req);
  const backend = await getBackend();
  const body = req.body;
  if (typeof body !== "object" || body === null || !("changes" in body)) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: 'Request body must include a "changes" array' } });
    return;
  }
  const { changes } = body;
  if (!Array.isArray(changes)) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: '"changes" must be an array' } });
    return;
  }
  for (const change of changes) {
    const validatedPath = validateDraftPath(change.path);
    if (change.action === "upsert") {
      if (typeof change.content !== "string") {
        res.status(400).json({ error: { code: "BAD_REQUEST", message: `Missing content for upsert of "${change.path}"` } });
        return;
      }
      await backend.saveDraft(user.userId, validatedPath, change.content);
    } else if (change.action === "delete") {
      await backend.deleteDraft(user.userId, validatedPath);
    } else {
      res.status(400).json({
        error: {
          code: "BAD_REQUEST",
          message: `Invalid action for path "${String(change.path)}". Must be "upsert" or "delete".`
        }
      });
      return;
    }
  }
  res.json({ accepted: changes.length });
}));
draftsRouter.get("/api/studio/drafts/{*filePath}", asyncHandler(async (req, res) => {
  const filePath = String(req.params["filePath"] ?? "");
  const validatedPath = validateDraftPath(filePath);
  const user = await getUser(req);
  const backend = await getBackend();
  const draft = await backend.readDraft(user.userId, validatedPath);
  if (!draft) {
    res.status(404).json({ error: { code: "NOT_FOUND", message: `Draft not found: ${validatedPath}` } });
    return;
  }
  res.json(draft);
}));
draftsRouter.put("/api/studio/drafts/{*filePath}", asyncHandler(async (req, res) => {
  const filePath = String(req.params["filePath"] ?? "");
  const validatedPath = validateDraftPath(filePath);
  const user = await getUser(req);
  const backend = await getBackend();
  let content;
  if (typeof req.body === "string") {
    content = req.body;
  } else if (typeof req.body === "object" && req.body !== null && "content" in req.body) {
    content = String(req.body["content"]);
  } else {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: 'Request body must be text or JSON with a "content" field' } });
    return;
  }
  await backend.saveDraft(user.userId, validatedPath, content);
  res.json({ ok: true });
}));
draftsRouter.delete("/api/studio/drafts/{*filePath}", asyncHandler(async (req, res) => {
  const filePath = String(req.params["filePath"] ?? "");
  const validatedPath = validateDraftPath(filePath);
  const user = await getUser(req);
  const backend = await getBackend();
  await backend.deleteDraft(user.userId, validatedPath);
  res.json({ ok: true });
}));

// src/server/routes/publish.ts
import { Router as Router4 } from "express";
var publishRouter = Router4();
publishRouter.post("/api/studio/publish", asyncHandler(async (req, res) => {
  const user = await getUser(req);
  const backend = await getBackend();
  const result = await backend.publishDrafts(user.userId);
  res.json(result);
}));

// src/server/routes/discard.ts
import { Router as Router5 } from "express";
var discardRouter = Router5();
discardRouter.post("/api/studio/discard", asyncHandler(async (req, res) => {
  const user = await getUser(req);
  const backend = await getBackend();
  const discarded = await backend.discardAllDrafts(user.userId);
  res.json({ discarded });
}));

// src/server/routes/preview.ts
import { Router as Router6 } from "express";
var previewRouter = Router6();
previewRouter.post("/api/studio/preview", asyncHandler(async (_req, _res) => {
  throw new StudioFeatureUnavailableError(
    "preview",
    "Preview is not available in local development mode. Publish directly instead."
  );
}));

// src/server/routes/stores.ts
import { Router as Router7 } from "express";

// src/lib/store-queries.ts
import { eq as eq3, desc as desc2, and as and2, count, storeDocuments, storeDocumentVersions } from "@amodalai/db";
async function listStores(agentId) {
  const db = await getStudioDb();
  return db.select({ store: storeDocuments.store, docCount: count() }).from(storeDocuments).where(eq3(storeDocuments.appId, agentId)).groupBy(storeDocuments.store);
}
async function listDocuments(agentId, store, opts) {
  const db = await getStudioDb();
  let query = db.select().from(storeDocuments).where(and2(eq3(storeDocuments.appId, agentId), eq3(storeDocuments.store, store))).orderBy(desc2(storeDocuments.updatedAt)).$dynamic();
  if (opts?.limit) query = query.limit(opts.limit);
  if (opts?.offset) query = query.offset(opts.offset);
  return query;
}
async function getDocument(agentId, store, key) {
  const db = await getStudioDb();
  const rows = await db.select().from(storeDocuments).where(
    and2(
      eq3(storeDocuments.appId, agentId),
      eq3(storeDocuments.store, store),
      eq3(storeDocuments.key, key)
    )
  ).limit(1);
  return rows[0] ?? null;
}
async function getDocumentHistory(agentId, store, key) {
  const db = await getStudioDb();
  return db.select().from(storeDocumentVersions).where(
    and2(
      eq3(storeDocumentVersions.appId, agentId),
      eq3(storeDocumentVersions.store, store),
      eq3(storeDocumentVersions.key, key)
    )
  ).orderBy(desc2(storeDocumentVersions.version));
}

// src/server/routes/stores.ts
var storesRouter = Router7();
storesRouter.get("/api/studio/stores", asyncHandler(async (_req, res) => {
  const agentId = getAgentId();
  const stores = await listStores(agentId);
  res.json({ stores });
}));
storesRouter.get("/api/studio/stores/:name/documents", asyncHandler(async (req, res) => {
  const agentId = getAgentId();
  const name = String(req.params["name"] ?? "");
  const documents = await listDocuments(agentId, name);
  res.json({ documents });
}));
storesRouter.get("/api/studio/stores/:name/documents/:key", asyncHandler(async (req, res) => {
  const agentId = getAgentId();
  const name = String(req.params["name"] ?? "");
  const key = String(req.params["key"] ?? "");
  const [document, history] = await Promise.all([
    getDocument(agentId, name, key),
    getDocumentHistory(agentId, name, key)
  ]);
  if (!document) {
    res.status(404).json({ error: { code: "NOT_FOUND", message: `Document not found: ${name}/${key}` } });
    return;
  }
  res.json({ document, history });
}));

// src/server/routes/automations.ts
import { Router as Router8 } from "express";

// src/lib/automation-queries.ts
import { eq as eq4, and as and3, desc as desc3, automationConfig, automationRuns } from "@amodalai/db";
var DEFAULT_RUNS_LIMIT2 = 50;
async function listAutomations(agentId) {
  const db = await getStudioDb();
  return db.select().from(automationConfig).where(eq4(automationConfig.agentId, agentId)).orderBy(desc3(automationConfig.createdAt));
}
async function getAutomation(agentId, name) {
  const db = await getStudioDb();
  const rows = await db.select().from(automationConfig).where(
    and3(
      eq4(automationConfig.agentId, agentId),
      eq4(automationConfig.name, name)
    )
  ).limit(1);
  return rows[0] ?? null;
}
async function upsertAutomation(agentId, name, data) {
  const db = await getStudioDb();
  const now = /* @__PURE__ */ new Date();
  await db.insert(automationConfig).values({
    agentId,
    name,
    schedule: data.schedule,
    message: data.message,
    enabled: data.enabled ?? false,
    createdAt: now,
    updatedAt: now
  }).onConflictDoUpdate({
    target: [automationConfig.agentId, automationConfig.name],
    set: {
      schedule: data.schedule,
      message: data.message,
      ...data.enabled !== void 0 ? { enabled: data.enabled } : {},
      updatedAt: now
    }
  });
}
async function setAutomationEnabled(agentId, name, enabled) {
  const db = await getStudioDb();
  await db.update(automationConfig).set({ enabled, updatedAt: /* @__PURE__ */ new Date() }).where(
    and3(
      eq4(automationConfig.agentId, agentId),
      eq4(automationConfig.name, name)
    )
  );
}
async function recordAutomationRun(agentId, name, sessionId, status, error) {
  const db = await getStudioDb();
  const rows = await db.insert(automationRuns).values({
    agentId,
    name,
    sessionId,
    status,
    error: error ?? null,
    startedAt: /* @__PURE__ */ new Date(),
    completedAt: status !== "running" ? /* @__PURE__ */ new Date() : null
  }).returning({ id: automationRuns.id });
  return rows[0]?.id ?? 0;
}
async function completeAutomationRun(runId, status, opts) {
  const db = await getStudioDb();
  await db.update(automationRuns).set({
    status,
    completedAt: /* @__PURE__ */ new Date(),
    ...opts?.sessionId !== void 0 ? { sessionId: opts.sessionId } : {},
    ...opts?.error !== void 0 ? { error: opts.error } : {}
  }).where(eq4(automationRuns.id, runId));
}
async function listAutomationRuns(agentId, name, limit = DEFAULT_RUNS_LIMIT2) {
  const db = await getStudioDb();
  return db.select().from(automationRuns).where(
    and3(
      eq4(automationRuns.agentId, agentId),
      eq4(automationRuns.name, name)
    )
  ).orderBy(desc3(automationRuns.startedAt)).limit(limit);
}

// src/lib/runtime-client.ts
var RUNTIME_URL_ENV = "RUNTIME_URL";
function getRuntimeUrl2() {
  const url = process.env[RUNTIME_URL_ENV];
  if (!url) throw new Error(`${RUNTIME_URL_ENV} is not configured`);
  return url;
}

// src/lib/automation-scheduler.ts
import {
  notifyAutomationStarted,
  notifyAutomationCompleted
} from "@amodalai/db";
var AUTOMATION_TIMEOUT_MS = 3e5;
var RUNTIME_CHAT_PATH = "/chat";
function cronToIntervalMs(schedule) {
  const parts = schedule.trim().split(/\s+/);
  if (parts.length !== 5) return 0;
  const [minute, hour, dayOfMonth, month, dayOfWeek] = parts;
  if (minute?.startsWith("*/") && hour === "*" && dayOfMonth === "*" && month === "*" && dayOfWeek === "*") {
    const n = parseInt(minute.slice(2), 10);
    if (Number.isNaN(n) || n <= 0) return 0;
    return n * 60 * 1e3;
  }
  if (minute !== void 0 && /^\d+$/.test(minute) && hour === "*" && dayOfMonth === "*" && month === "*" && dayOfWeek === "*") {
    return 60 * 60 * 1e3;
  }
  if (minute !== void 0 && /^\d+$/.test(minute) && hour !== void 0 && /^\d+$/.test(hour) && dayOfMonth === "*" && month === "*" && dayOfWeek === "*") {
    return 24 * 60 * 60 * 1e3;
  }
  return 0;
}
var AutomationScheduler = class {
  timers = /* @__PURE__ */ new Map();
  agentId;
  constructor(agentId) {
    this.agentId = agentId;
  }
  /**
   * Load enabled automations from DB and start their timers.
   */
  async start() {
    const automations = await listAutomations(this.agentId);
    let started = 0;
    for (const auto of automations) {
      if (auto.enabled) {
        this.scheduleOne(auto.name, auto.schedule, auto.message);
        started++;
      }
    }
    logger.info("scheduler_started", { agent_id: this.agentId, automations_scheduled: started });
  }
  /**
   * Schedule a single automation to fire on an interval.
   */
  scheduleOne(name, schedule, message) {
    this.clearOne(name);
    const intervalMs = cronToIntervalMs(schedule);
    if (intervalMs <= 0) {
      logger.warn("unsupported_cron_schedule", { name, schedule, agent_id: this.agentId });
      return;
    }
    const timer = setInterval(() => {
      void this.trigger(name, message).catch((err) => {
        const errorMsg = err instanceof Error ? err.message : String(err);
        logger.error("automation_trigger_unhandled", { name, error: errorMsg, agent_id: this.agentId });
      });
    }, intervalMs);
    this.timers.set(name, timer);
    logger.info("automation_scheduled", { name, interval_ms: intervalMs, agent_id: this.agentId });
  }
  /**
   * Trigger an automation run immediately.
   */
  async trigger(name, message) {
    const db = await getStudioDb();
    const rawDb = db;
    const runId = await recordAutomationRun(this.agentId, name, null, "running");
    await notifyAutomationStarted(rawDb, { agentId: this.agentId, name, runId });
    logger.info("automation_triggered", { name, run_id: runId, agent_id: this.agentId });
    const start = Date.now();
    try {
      const runtimeUrl = getRuntimeUrl2();
      const res = await fetch(`${runtimeUrl}${RUNTIME_CHAT_PATH}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, metadata: { automation: name } }),
        signal: AbortSignal.timeout(AUTOMATION_TIMEOUT_MS)
      });
      const data = await res.json();
      const sessionId = typeof data === "object" && data !== null && "sessionId" in data ? String(data["sessionId"]) : null;
      await completeAutomationRun(runId, "completed", { sessionId: sessionId ?? void 0 });
      await notifyAutomationCompleted(rawDb, {
        agentId: this.agentId,
        name,
        runId,
        status: "completed"
      });
      logger.info("automation_completed", {
        name,
        run_id: runId,
        session_id: sessionId,
        duration_ms: Date.now() - start,
        agent_id: this.agentId
      });
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      await completeAutomationRun(runId, "failed", { error: errorMsg });
      await notifyAutomationCompleted(rawDb, {
        agentId: this.agentId,
        name,
        runId,
        status: "failed"
      });
      logger.error("automation_failed", {
        name,
        run_id: runId,
        error: errorMsg,
        duration_ms: Date.now() - start,
        agent_id: this.agentId
      });
      throw err;
    }
  }
  /**
   * Enable and schedule an automation.
   */
  enableAutomation(name, schedule, message) {
    this.scheduleOne(name, schedule, message);
  }
  /**
   * Disable and remove a scheduled automation.
   */
  disableAutomation(name) {
    this.clearOne(name);
    logger.info("automation_disabled", { name, agent_id: this.agentId });
  }
  /**
   * Stop all timers. Called on shutdown.
   */
  stop() {
    for (const [name, timer] of this.timers.entries()) {
      clearInterval(timer);
      logger.debug("automation_timer_cleared", { name, agent_id: this.agentId });
    }
    this.timers.clear();
    logger.info("scheduler_stopped", { agent_id: this.agentId });
  }
  clearOne(name) {
    const existing = this.timers.get(name);
    if (existing) {
      clearInterval(existing);
      this.timers.delete(name);
    }
  }
};
var scheduler = null;
function getScheduler(agentId) {
  if (!scheduler) {
    scheduler = new AutomationScheduler(agentId);
  }
  return scheduler;
}

// src/server/routes/automations.ts
var automationsRouter = Router8();
automationsRouter.get("/api/studio/automations", asyncHandler(async (_req, res) => {
  const agentId = getAgentId();
  const automations = await listAutomations(agentId);
  res.json({ automations });
}));
automationsRouter.post("/api/studio/automations", asyncHandler(async (req, res) => {
  const agentId = getAgentId();
  const body = req.body;
  if (typeof body !== "object" || body === null) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: "Request body must be a JSON object" } });
    return;
  }
  const { name, schedule, message, enabled } = body;
  if (typeof name !== "string" || typeof schedule !== "string" || typeof message !== "string") {
    res.status(400).json({
      error: { code: "BAD_REQUEST", message: "name, schedule, and message are required string fields" }
    });
    return;
  }
  await upsertAutomation(agentId, name, {
    schedule,
    message,
    enabled: typeof enabled === "boolean" ? enabled : void 0
  });
  res.json({ ok: true });
}));
automationsRouter.get("/api/studio/automations/:name", asyncHandler(async (req, res) => {
  const agentId = getAgentId();
  const name = String(req.params["name"] ?? "");
  const [automation, runs] = await Promise.all([
    getAutomation(agentId, name),
    listAutomationRuns(agentId, name)
  ]);
  if (!automation) {
    res.status(404).json({ error: { code: "NOT_FOUND", message: `Automation not found: ${name}` } });
    return;
  }
  res.json({ automation, runs });
}));
automationsRouter.post("/api/studio/automations/:name/run", asyncHandler(async (req, res) => {
  const agentId = getAgentId();
  const name = String(req.params["name"] ?? "");
  const body = req.body;
  const message = typeof body === "object" && body !== null && "message" in body ? String(body["message"]) : name;
  const scheduler2 = getScheduler(agentId);
  await scheduler2.trigger(name, message);
  res.json({ ok: true });
}));
automationsRouter.post("/api/studio/automations/:name/start", asyncHandler(async (req, res) => {
  const agentId = getAgentId();
  const name = String(req.params["name"] ?? "");
  await setAutomationEnabled(agentId, name, true);
  const automation = await getAutomation(agentId, name);
  if (automation) {
    const scheduler2 = getScheduler(agentId);
    scheduler2.enableAutomation(name, automation.schedule, automation.message);
  }
  res.json({ ok: true });
}));
automationsRouter.post("/api/studio/automations/:name/stop", asyncHandler(async (req, res) => {
  const agentId = getAgentId();
  const name = String(req.params["name"] ?? "");
  await setAutomationEnabled(agentId, name, false);
  const scheduler2 = getScheduler(agentId);
  scheduler2.disableAutomation(name);
  res.json({ ok: true });
}));

// src/server/routes/evals.ts
import { Router as Router9 } from "express";

// src/lib/eval-runner.ts
var EvalRunnerError = class extends StudioError {
  constructor(message, options) {
    super("EVAL_RUNNER_ERROR", message, 500, { suiteId: options.suiteId }, options.cause);
    this.name = "EvalRunnerError";
  }
};
var CASE_TIMEOUT_MS = 6e4;
async function runEvalSuite(suiteId, agentId) {
  const suite = await getEvalSuite(suiteId);
  if (!suite) {
    throw new EvalRunnerError(`Eval suite ${suiteId} not found`, { suiteId });
  }
  const runtimeUrl = getRuntimeUrl2();
  const config = suite.config;
  const results = [];
  const startTime = Date.now();
  logger.info("eval_run_started", { suiteId, agentId, caseCount: config.cases.length });
  for (const testCase of config.cases) {
    const caseStart = Date.now();
    try {
      const res = await fetch(`${runtimeUrl}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: testCase.input }),
        signal: AbortSignal.timeout(CASE_TIMEOUT_MS)
      });
      const data = await res.json();
      const output = data.response ?? "";
      const passed = testCase.expected ? output.includes(testCase.expected) : true;
      results.push({ input: testCase.input, output, passed, durationMs: Date.now() - caseStart });
    } catch (err) {
      logger.warn("eval_case_error", {
        suiteId,
        input: testCase.input,
        error: err instanceof Error ? err.message : String(err)
      });
      results.push({
        input: testCase.input,
        output: err instanceof Error ? err.message : String(err),
        passed: false,
        durationMs: Date.now() - caseStart
      });
    }
  }
  const totalPassed = results.filter((r) => r.passed).length;
  const runId = crypto.randomUUID();
  const durationMs = Date.now() - startTime;
  await saveEvalRun({
    id: runId,
    agentId,
    suiteId,
    model: {},
    results,
    passRate: results.length > 0 ? totalPassed / results.length : 0,
    totalPassed,
    totalFailed: results.length - totalPassed,
    durationMs,
    triggeredBy: "manual"
  });
  logger.info("eval_run_completed", {
    suiteId,
    runId,
    totalPassed,
    totalFailed: results.length - totalPassed,
    durationMs
  });
  return runId;
}

// src/server/routes/evals.ts
var evalsRouter = Router9();
evalsRouter.get("/api/studio/evals", asyncHandler(async (req, res) => {
  const agentId = String(req.query["agentId"] ?? "");
  if (!agentId) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: "agentId query parameter is required" } });
    return;
  }
  const suites = await listEvalSuites(agentId);
  res.json({ suites });
}));
evalsRouter.get("/api/studio/evals/:id", asyncHandler(async (req, res) => {
  const id = String(req.params["id"] ?? "");
  const suite = await getEvalSuite(id);
  if (!suite) {
    res.status(404).json({ error: { code: "NOT_FOUND", message: `Eval suite not found: ${id}` } });
    return;
  }
  res.json({ suite });
}));
evalsRouter.post("/api/studio/evals/:id/run", asyncHandler(async (req, res) => {
  const id = String(req.params["id"] ?? "");
  const body = req.body;
  if (typeof body !== "object" || body === null || !("agentId" in body)) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: 'Request body must include "agentId"' } });
    return;
  }
  const agentId = String(body["agentId"]);
  const runId = await runEvalSuite(id, agentId);
  res.json({ runId });
}));
evalsRouter.get("/api/studio/evals/:id/results", asyncHandler(async (req, res) => {
  const id = String(req.params["id"] ?? "");
  const runs = await listEvalRuns(id);
  res.json({ runs });
}));

// src/server/routes/feedback.ts
import { Router as Router10 } from "express";

// src/lib/feedback-queries.ts
import { eq as eq5, desc as desc4, count as count2, inArray, feedback } from "@amodalai/db";
var DEFAULT_FEEDBACK_LIMIT = 500;
async function listFeedback(agentId, limit = DEFAULT_FEEDBACK_LIMIT) {
  const db = await getStudioDb();
  return db.select().from(feedback).where(eq5(feedback.agentId, agentId)).orderBy(desc4(feedback.createdAt)).limit(limit);
}
async function getFeedbackSummary(agentId) {
  const db = await getStudioDb();
  const rows = await db.select({ rating: feedback.rating, total: count2() }).from(feedback).where(eq5(feedback.agentId, agentId)).groupBy(feedback.rating);
  const up = rows.find((r) => r.rating === "up")?.total ?? 0;
  const down = rows.find((r) => r.rating === "down")?.total ?? 0;
  return { up, down, total: up + down };
}
async function markFeedbackReviewed(ids) {
  if (ids.length === 0) return;
  const db = await getStudioDb();
  await db.update(feedback).set({ reviewedAt: /* @__PURE__ */ new Date() }).where(inArray(feedback.id, ids));
}

// src/server/routes/feedback.ts
var feedbackRouter = Router10();
feedbackRouter.get("/api/studio/feedback", asyncHandler(async (req, res) => {
  const agentId = String(req.query["agentId"] ?? "");
  if (!agentId) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: "agentId query parameter is required" } });
    return;
  }
  const entries = await listFeedback(agentId);
  res.json({ entries });
}));
feedbackRouter.get("/api/studio/feedback/summary", asyncHandler(async (req, res) => {
  const agentId = String(req.query["agentId"] ?? "");
  if (!agentId) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: "agentId query parameter is required" } });
    return;
  }
  const summary = await getFeedbackSummary(agentId);
  res.json({ summary });
}));
feedbackRouter.post("/api/studio/feedback/mark-reviewed", asyncHandler(async (req, res) => {
  const body = req.body;
  if (typeof body !== "object" || body === null || !("ids" in body)) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: 'Request body must include "ids" array' } });
    return;
  }
  const { ids } = body;
  if (!Array.isArray(ids) || !ids.every((id) => typeof id === "string")) {
    res.status(400).json({ error: { code: "BAD_REQUEST", message: '"ids" must be an array of strings' } });
    return;
  }
  await markFeedbackReviewed(ids);
  res.json({ ok: true });
}));

// src/server/routes/events.ts
import { Router as Router11 } from "express";
var HEARTBEAT_INTERVAL_MS = 15e3;
var eventsRouter = Router11();
eventsRouter.get("/api/studio/events", asyncHandler(async (req, res) => {
  await initEventBridge();
  const bus2 = getEventBus();
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();
  const unsub = bus2.subscribe((event) => {
    res.write(`id: ${event.seq}
event: ${event.type}
data: ${JSON.stringify(event.payload)}

`);
  });
  const heartbeat = setInterval(() => {
    res.write(":\n\n");
  }, HEARTBEAT_INTERVAL_MS);
  let cleanedUp = false;
  const cleanup = () => {
    if (cleanedUp) return;
    cleanedUp = true;
    clearInterval(heartbeat);
    unsub();
  };
  req.on("close", cleanup);
  res.on("close", cleanup);
}));

// src/server/routes/admin-chat.ts
import { Router as Router12 } from "express";
var ADMIN_CHAT_TIMEOUT_MS = 3e5;
var adminChatRouter = Router12();
adminChatRouter.post("/api/studio/admin-chat/stream", asyncHandler(async (req, res) => {
  const adminUrl = getAdminAgentUrl();
  if (!adminUrl) {
    res.status(503).json({
      error: { code: "ADMIN_AGENT_NOT_CONFIGURED", message: "Admin agent not configured" }
    });
    return;
  }
  let upstream;
  try {
    upstream = await fetch(`${adminUrl}/chat/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body),
      signal: AbortSignal.timeout(ADMIN_CHAT_TIMEOUT_MS)
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error("admin_chat_fetch_error", { error: message });
    res.status(502).json({
      error: { code: "ADMIN_AGENT_UNREACHABLE", message: "Failed to reach admin agent" }
    });
    return;
  }
  if (!upstream.ok) {
    res.status(upstream.status);
    if (upstream.body) {
      const reader = upstream.body.getReader();
      try {
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(value);
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        logger.warn("admin_chat_upstream_read_error", { error: message });
      }
      res.end();
    } else {
      res.end();
    }
    return;
  }
  res.setHeader("Content-Type", upstream.headers.get("Content-Type") ?? "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  if (upstream.body) {
    const reader = upstream.body.getReader();
    const pump = async () => {
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(value);
      }
      res.end();
    };
    pump().catch((err) => {
      const message = err instanceof Error ? err.message : String(err);
      logger.warn("admin_chat_pump_error", { error: message });
      res.end();
    });
    req.on("close", () => {
      reader.cancel().catch((err) => {
        logger.debug("admin_chat_reader_cancel", {
          error: err instanceof Error ? err.message : String(err)
        });
      });
    });
  } else {
    res.end();
  }
}));

// src/server/routes/runtime-proxy.ts
import { Router as Router13 } from "express";
var RUNTIME_PROXY_TIMEOUT_MS = 5e3;
var runtimeProxyRouter = Router13();
runtimeProxyRouter.get("/api/runtime/files", asyncHandler(async (_req, res) => {
  const runtimeUrl = getRuntimeUrl();
  if (!runtimeUrl) {
    res.status(503).json({ error: { code: "RUNTIME_URL_NOT_CONFIGURED", message: "RUNTIME_URL not configured" } });
    return;
  }
  try {
    const upstream = await fetch(`${runtimeUrl}/api/files`, {
      signal: AbortSignal.timeout(RUNTIME_PROXY_TIMEOUT_MS)
    });
    res.status(upstream.status);
    res.setHeader("Content-Type", upstream.headers.get("Content-Type") ?? "application/json");
    const body = await upstream.text();
    res.send(body);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error("runtime_proxy_error", { path: "/api/files", error: message });
    res.status(502).json({ error: { code: "RUNTIME_UNREACHABLE", message: "Failed to reach runtime" } });
  }
}));
runtimeProxyRouter.get("/api/runtime/files/{*filePath}", asyncHandler(async (req, res) => {
  const filePath = String(req.params["filePath"] ?? "");
  const runtimeUrl = getRuntimeUrl();
  if (!runtimeUrl) {
    res.status(503).json({ error: { code: "RUNTIME_URL_NOT_CONFIGURED", message: "RUNTIME_URL not configured" } });
    return;
  }
  const upstreamPath = filePath ? `/api/files/${filePath}` : "/api/files";
  try {
    const upstream = await fetch(`${runtimeUrl}${upstreamPath}`, {
      signal: AbortSignal.timeout(RUNTIME_PROXY_TIMEOUT_MS)
    });
    res.status(upstream.status);
    res.setHeader("Content-Type", upstream.headers.get("Content-Type") ?? "application/json");
    const body = await upstream.text();
    res.send(body);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error("runtime_proxy_error", { path: upstreamPath, error: message });
    res.status(502).json({ error: { code: "RUNTIME_UNREACHABLE", message: "Failed to reach runtime" } });
  }
}));

// src/server/studio-server.ts
var __dirname = path3.dirname(fileURLToPath(import.meta.url));
var DEFAULT_PORT = 3848;
async function main() {
  const port = parseInt(process.env["PORT"] ?? String(DEFAULT_PORT), 10);
  const app = express();
  app.use("/api", corsMiddleware);
  app.use(express.json({ limit: "10mb" }));
  app.use(express.text({ limit: "10mb" }));
  app.use(configRouter);
  app.use(workspaceRouter);
  app.use(draftsRouter);
  app.use(publishRouter);
  app.use(discardRouter);
  app.use(previewRouter);
  app.use(storesRouter);
  app.use(automationsRouter);
  app.use(evalsRouter);
  app.use(feedbackRouter);
  app.use(eventsRouter);
  app.use(adminChatRouter);
  app.use(runtimeProxyRouter);
  const distDir = existsSync(path3.resolve(__dirname, "..", "..", "dist", "index.html")) ? path3.resolve(__dirname, "..", "..", "dist") : path3.resolve(__dirname, "..", "dist");
  if (existsSync(path3.join(distDir, "index.html"))) {
    app.use(express.static(distDir));
    app.get("{*path}", (req, res, next) => {
      if (req.path.startsWith("/api/")) {
        next();
        return;
      }
      res.sendFile(path3.join(distDir, "index.html"));
    });
  }
  app.use(errorHandler);
  await initEventBridge();
  const repoPath = process.env["REPO_PATH"];
  if (repoPath) {
    await getBackend();
    const agentId = getAgentId();
    try {
      const loaded = await loadEvalsFromDisk(repoPath, agentId);
      if (loaded > 0) {
        logger.info("eval_suites_loaded_at_startup", { agentId, loaded });
      }
    } catch (err) {
      logger.warn("eval_suites_load_failed", {
        agentId,
        error: err instanceof Error ? err.message : String(err)
      });
    }
  }
  const server = app.listen(port, "localhost", () => {
    logger.info("studio_server_started", { port });
  });
  const shutdown = async (signal) => {
    logger.info("studio_server_shutdown", { signal });
    await closePgListener();
    server.close();
    process.exit(0);
  };
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("SIGINT", () => void shutdown("SIGINT"));
}
main().catch((err) => {
  const message = err instanceof Error ? err.message : String(err);
  logger.error("studio_server_fatal", { error: message });
  process.exit(1);
});
/**
 * @license
 * Copyright 2026 Amodal Labs, Inc.
 * SPDX-License-Identifier: MIT
 */
//# sourceMappingURL=studio-server.js.map
