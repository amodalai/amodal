#!/usr/bin/env node
/**
 * @license
 * Copyright 2025 Amodal Labs, Inc.
 * SPDX-License-Identifier: MIT
 */

import {readFileSync} from 'node:fs';
import yargs from 'yargs';
import {hideBin} from 'yargs/helpers';

// Console interception is now handled by interceptConsole() in the logger,
// called from dev/serve commands. The old manual hack is no longer needed.

import {amodalCommands} from './commands/index.js';
import {loadEnvFile} from './shared/load-env.js';

// Load .env from current directory before anything else
loadEnvFile(process.cwd());

const raw: unknown = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf-8'));
if (typeof raw !== 'object' || raw === null || !('version' in raw) || typeof raw.version !== 'string') {
  throw new Error('Failed to read version from package.json');
}
// Detect source build: pnpm-workspace.yaml exists at repo root (4 levels up from dist/src/main.js)
const isSourceBuild = (() => {
  try { return readFileSync(new URL('../../../../pnpm-workspace.yaml', import.meta.url), 'utf-8').length > 0; } catch { return false; }
})();
const pkgVersion = raw.version + (isSourceBuild ? '-dev' : '');

const cli = yargs(hideBin(process.argv))
  .scriptName('amodal')
  .usage('$0 <command> [options]');

for (const cmd of amodalCommands) {
  cli.command(cmd);
}

cli
  .demandCommand(1, 'Run amodal <command> --help for usage')
  .strict()
  .help()
  .alias('h', 'help')
  .version(process.env['CLI_VERSION'] ?? pkgVersion)
  .alias('v', 'version');

void cli.parse();
